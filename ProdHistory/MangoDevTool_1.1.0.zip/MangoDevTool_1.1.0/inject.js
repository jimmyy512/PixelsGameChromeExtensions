if (isGetAppInit()) {
  window.getApp().$conf.debug = true;
}
const interval = setInterval(() => {
  if (isGetAppInit()) {
    window.getApp().$conf.debug = true;
  }
  if (isGetAppInit() && window.getApp().$conf.debug) {
    clearInterval(interval);
  }
}, 0);

function isGetAppInit() {
  return typeof window.getApp === 'function';
}
