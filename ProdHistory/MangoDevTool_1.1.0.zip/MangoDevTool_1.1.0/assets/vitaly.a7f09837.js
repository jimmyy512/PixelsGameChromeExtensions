const s="/assets/vitaly.7727a880.png";export{s as _};
