import"./modulepreload-polyfill.c7c6310f.js";chrome.devtools.panels.create("PixelsGame","","src/devtools_page/devPanel.html",function(e){console.log("success")});
