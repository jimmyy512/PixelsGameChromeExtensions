import"./modulepreload-polyfill.c7c6310f.js";chrome.devtools.panels.create("MangoDev","","src/devtools_page/devPanel.html",function(e){console.log("success")});
